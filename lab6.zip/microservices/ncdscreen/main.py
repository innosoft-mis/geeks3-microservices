from fastapi import FastAPI
import pandas as pd 
import sqlalchemy as sa

app = FastAPI()

@app.get("/")
async def root():

	conn_str = 'mysql+pymysql://user:user@ncdscreen-db:3306/ncdscreen'
	engine = sa.create_engine(conn_str)
	conn = engine.connect()
	ncd = pd.read_sql("ncd_screen", conn)
	conn.close()

	return ncd.to_dict("records")

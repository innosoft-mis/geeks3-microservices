CREATE DATABASE IF NOT EXISTS `ncdscreen`;
GRANT ALL ON `ncdscreen`.* TO 'user'@'%’;

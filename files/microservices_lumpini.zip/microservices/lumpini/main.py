from fastapi import FastAPI
import pandas as pd 
import sqlalchemy as sa
import requests

app = FastAPI()

def get_all_lumpini_data():

	conn_str = 'mysql+pymysql://user:user@lumpini-db:3306/lumpini'
	engine = sa.create_engine(conn_str)
	conn = engine.connect()
	lumpini = pd.read_sql("lumpini_pantip_trend", conn)
	conn.close()

	return lumpini

@app.get("/")
async def root():
	lumpini = get_all_lumpini_data()
	return lumpini.to_dict("records")

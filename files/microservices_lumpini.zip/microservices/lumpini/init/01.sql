CREATE DATABASE IF NOT EXISTS `lumpini`;
GRANT ALL ON `lumpini`.* TO 'user'@'%';

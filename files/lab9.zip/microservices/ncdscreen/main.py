from fastapi import FastAPI
import pandas as pd 
import sqlalchemy as sa
import requests

app = FastAPI()

def get_all_ncd_screen_data():

	conn_str = 'mysql+pymysql://user:user@ncdscreen-db:3306/ncdscreen'
	engine = sa.create_engine(conn_str)
	conn = engine.connect()
	hospital = pd.read_sql("ncd_screen", conn)
	conn.close()

	return hospital

@app.get("/")
async def root():
	ncd_screen = get_all_ncd_screen_data()
	return ncd_screen.to_dict("records")

@app.get("/with-hospital/")
async def with_hospital():
	ncd_screen = get_all_ncd_screen_data()
	r = requests.get("http://hospital")
	data = r.json()
	hospital = pd.DataFrame(data)
	new_ncd = pd.merge(ncd_screen, hospital, on='hospcode', how='inner')
	return new_ncd.to_dict("records")
	
@app.get("/status/")
async def status():
	return {'status': 'Online'}
